<?php
/**
 * Template for displaying countdown quiz.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/content-quiz/countdown.php.
 *
 * @author  ThimPress
 * @package  Learnpress/Templates
 * @version  3.0.0
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();
?>
