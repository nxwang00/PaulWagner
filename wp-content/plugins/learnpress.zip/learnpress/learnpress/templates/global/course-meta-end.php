<?php
/**
 * Template for displaying course meta end.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/global/course-meta-end.php.
 *
 * @author  ThimPress
 * @package  Learnpress/Templates
 * @version  3.0.0
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();
?>

</div>