<?php
/**
 * Template for displaying login.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/global/login.php.
 *
 * @author  ThimPress
 * @package  Learnpress/Templates
 * @version  3.0.0
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();
?>