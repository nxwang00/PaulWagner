
{{header}}

<p>Your Become an Instructor request at <strong>{{site_title}}</strong> has been denied</p>

{{footer}}