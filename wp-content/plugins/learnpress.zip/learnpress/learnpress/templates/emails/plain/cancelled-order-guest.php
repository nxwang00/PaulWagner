
== {{header}} ==

** Hi "Guest", **

** Your recent order at "{{site_title}}" has been cancelled. **

** See your order details below: **

{{order_items_table}}

== {{footer}} ==