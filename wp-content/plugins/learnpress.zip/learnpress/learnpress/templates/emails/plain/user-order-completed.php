
== {{email_heading}} ==

{order_items_table}

View order: {{order_detail_url}}

{{footer_text}}
