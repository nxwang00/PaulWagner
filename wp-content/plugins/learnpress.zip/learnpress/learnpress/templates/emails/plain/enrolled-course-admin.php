
== {{header}} ==

** User {{user_display_name}} ({{user_email}}) has enrolled course "{{course_name}}" {{course_url}} **

== {{footer}} ==