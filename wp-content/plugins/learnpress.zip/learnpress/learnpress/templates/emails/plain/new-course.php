
== {{email_heading}} ==

A new course "{{course_name}}" has been submitted is waiting for your approval

Please review course at {{course_edit_url}}

{{footer_text}}