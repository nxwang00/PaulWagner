== {{header}} ==

** Congrats! You become an Instructor at "{{site_title}}" **

** Please login {{login_url}} to "{{site_title}}" and start teaching. **

== {{footer}} ==