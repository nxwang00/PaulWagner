== {{header}} ==

** Order placed by "{{order_user_name}}" has been completed **

{{order_items_table}}

== {{footer}} ==