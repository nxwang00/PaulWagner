
== {{header}} ==

** Congrats! You have finished course "{{course_name}}" {{course_url}} **

** You achieved {{course_result_percent}} of course and your grade is {{course_grade}} **

== {{footer}} ==