
== {{header}} ==

** User {{user_display_name}} ({{user_email}}) has finished course "{{course_name}}" {{course_url}} **

** User has "{{course_grade}}" course with {{course_result_percent}} of total **

== {{footer}} ==