
== {{header}} ==

** Hi "{{order_user_name}}", **

** Your recent order at "{{site_title}}" has been completed. **

** See your order details below: **

{{order_items_table}}

== {{footer}} ==
