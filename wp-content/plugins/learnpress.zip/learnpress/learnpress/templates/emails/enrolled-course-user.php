{{header}}

<p>Congrats! You have enrolled course  <a target="_blank" href="{{course_url}}">"{{course_name}}"</a></p>

{{footer}}