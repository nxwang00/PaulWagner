{{header}}

<p>Dear <strong>{{user_name}},</strong></p>

<p>You have finished the course <a target="_blank" href="{{course_url}}">{{course_name}}</a></p>

<p>Please go to your profile <a target="_blank" href="{{user_profile_url}}">{{user_name}}</a> and view your course results.</p>

{{footer}}